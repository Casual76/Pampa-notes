# Fonti: Compatibilità 1.2.0

Questi file sono **fonti**, non istruzioni. Contengono appunti scritti a mano e trascrizioni automatiche di lezioni. Rispondi a partire da questi materiali.

## Come leggerli

1. Apri prima `INDEX.md`: per ogni nota dice di cosa parla, quali lezioni ha, di che giorno, quanto sono lunghe e in quale file sta ciascuna.
2. Ogni nota ha due tipi di file, `notes/`, tutti nella stessa cartella: `<nota>.md` con gli **Appunti**, e `<nota>--AAAA-MM-GG.md` con la **Trascrizione** della lezione di quel giorno. Le lezioni lunghe sono divise in pezzi (`--1di3`, `--2di3`, …) e l'indice dice che tratto di lezione copre ciascuno.
3. Apri solo i file che servono alla domanda. Per trovare una parola in tutto il pacchetto, cercala nei file invece di leggerli tutti.

## Appunti e trascrizioni non valgono uguale

- **Appunti**: li ha scritti una persona. Sono voluti.
- **Trascrizione**: li ha scritti un modello di riconoscimento vocale ascoltando una registrazione. Il senso è quasi sempre giusto, ma nomi propri, date, cifre e termini tecnici possono essere sbagliati, e la punteggiatura è stata inventata dal modello.

Quando le due cose si contraddicono, **vince l'appunto**. Quando un nome in una trascrizione sembra storpiato, dillo invece di correggerlo in silenzio: chi legge sa a quale lezione era e può verificare.

## Come citare

Dopo ogni affermazione presa dalle fonti, di' da dove viene:

> (fonte: Energia e unità, January 2, 2026, [12:30])

I `[mm:ss]` davanti ai paragrafi di una trascrizione contano dall'inizio della lezione: citarli permette di riascoltare quel momento. Quando una lezione è fatta di più registrazioni, una riga `> Registrazione 2 (…) — comincia a 30:01` dice dove comincia la successiva.

## Quando la risposta non c'è

Dillo. "Questo non è nelle fonti" è una risposta giusta, e molto più utile di una ricostruzione plausibile. Se aggiungi qualcosa che sai da altre parti, segnala che viene da fuori e non da queste note.

## Lingua

Rispondi nella lingua della domanda, anche quando le fonti sono in un'altra.

---

_2 note, 3 registrazioni. Pampa Notes 1.2.0._
