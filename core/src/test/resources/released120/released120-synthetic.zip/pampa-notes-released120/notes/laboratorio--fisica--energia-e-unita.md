---
title: "Energia e unità"
id: r120-note
folder: "Fisica"
path: "Laboratorio/Fisica"
tags: ["fisica", "sintetico"]
created: 2026-01-02
updated: 2026-01-02
language: it
sources:
  - name: "r120-source-a.md"
    kind: markdown
    sha256: 4c4c61dd1c19616665f3c818615834e21adac7efa946ccc93476013edf5fa7e4
  - name: "r120-source-b.md"
    kind: markdown
    sha256: 4c4c61dd1c19616665f3c818615834e21adac7efa946ccc93476013edf5fa7e4
sessions:
  - date: 2026-01-02
    parts: 1
    duration_min: 0
    transcript: refined
    provider: custom
    model: "synthetic-no-inference"
    files: ["laboratorio--fisica--energia-e-unita--2026-01-02.md"]
  - date: 2026-01-02
    parts: 2
    duration_min: 0
    transcript: raw
    provider: custom
    model: "synthetic-no-inference"
    files: ["laboratorio--fisica--energia-e-unita--2026-01-02-2.md"]
generator: "Pampa Notes 1.2.0"
---

# Energia e unità

## Appunti

# Appunti sintetici

Energia: E = mc².
Un caffè e un'unità: µs.

## Sessioni

- **Sessione 1 — January 2, 2026 · Ripulita selezionata** · 1 registrazione, 0 min · trascrizione raffinata, synthetic-no-inference, 3 parole: [laboratorio--fisica--energia-e-unita--2026-01-02.md](laboratorio--fisica--energia-e-unita--2026-01-02.md)
- **Sessione 2 — January 2, 2026 · Grezza selezionata** · 2 registrazioni, 0 min · trascrizione grezza, synthetic-no-inference, 4 parole: [laboratorio--fisica--energia-e-unita--2026-01-02-2.md](laboratorio--fisica--energia-e-unita--2026-01-02-2.md)

## Fonti

- `r120-source-a.md` — markdown, 60 B
- `r120-source-b.md` — markdown, 60 B
