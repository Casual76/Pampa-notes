---
note: "Energia e unità"
folder: "Laboratorio/Fisica"
session: 2
date: 2026-01-02
time: "00:00–00:01"
transcript: raw
provider: custom
model: "synthetic-no-inference"
words: 4
notes_file: "laboratorio--fisica--energia-e-unita.md"
generator: "Pampa Notes 1.2.0"
---

# Trascrizione — Energia e unità · January 2, 2026

> Testo prodotto da un riconoscimento vocale: nomi propri, date, cifre e termini tecnici possono essere sbagliati, e la punteggiatura l'ha messa il modello. Gli appunti di questa nota stanno in [laboratorio--fisica--energia-e-unita.md](laboratorio--fisica--energia-e-unita.md).

Sessione 2 · Grezza selezionata · 2 registrazioni, 0 min · trascrizione grezza, synthetic-no-inference.

[00:00] Prima parte.

> Registrazione 2 (`Tono 3.m4a`) — comincia a 00:01

[00:01] Seconda parte.
