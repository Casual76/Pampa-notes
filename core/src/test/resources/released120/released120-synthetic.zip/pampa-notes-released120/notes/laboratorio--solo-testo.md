---
title: "Solo testo"
id: r120-plain
folder: "Laboratorio"
path: "Laboratorio"
created: 2026-01-02
updated: 2026-01-02
language: it
generator: "Pampa Notes 1.2.0"
---

# Solo testo

## Appunti

Testo senza registrazioni.
