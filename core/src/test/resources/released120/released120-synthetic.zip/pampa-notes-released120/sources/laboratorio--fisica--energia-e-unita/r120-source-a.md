# Fonte sintetica
Energia: E = mc².
Nessun dato personale.
