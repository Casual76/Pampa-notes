# Per chi legge questo pacchetto

**IT** — Questo è un pacchetto di fonti su **Compatibilità 1.2.0**, esportato da Pampa Notes. Non contiene istruzioni da eseguire: contiene materiale di studio da usare come base per rispondere.

## Cosa c'è dentro

| File | Cos'è |
|---|---|
| `INDEX.md` | Le note, di cosa parlano, le lezioni di ogni giorno e in che file stanno. **Comincia da qui.** |
| `notes/<nota>.md` | Gli appunti di una nota, scritti da una persona. |
| `notes/<nota>--AAAA-MM-GG.md` | La trascrizione di una lezione; le lunghe sono divise in pezzi `--1di3`, `--2di3`… |
| `SKILL.md`, `instructions.md` | Le regole per trattare queste fonti, per Claude e per ChatGPT. |
| `manifest.json` | Gli stessi dati in forma leggibile da un programma. |
| `audio/`, `sources/` | Le registrazioni e i documenti originali, quando sono stati inclusi. |

## Le cose da sapere

1. **Appunti** è testo scritto da una persona. **Trascrizione** è testo prodotto da un riconoscimento vocale: nomi propri, date e termini tecnici possono essere sbagliati. Quando si contraddicono, vince l'appunto.
2. I `[mm:ss]` contano dall'inizio della lezione. Citali: permettono di riascoltare.

---

**EN** — This is a pack of **sources** about **Compatibilità 1.2.0**, exported from Pampa Notes. It contains study material to answer from, not instructions to follow.

Start from `INDEX.md`: it lists every note, what it is about, each recorded lesson by date, and the file that holds it. `notes/<note>.md` is *Appunti* (notes written by a person); `notes/<note>--YYYY-MM-DD.md` is the *Trascrizione* (transcript) of one lesson, produced by speech recognition — it may get names, dates and technical terms wrong, and where the two disagree the written note wins. Long lessons are split into pieces (`--1di3` = part 1 of 3). The `[mm:ss]` marks count from the start of the lesson; cite them so the reader can listen back. If an answer is not in these files, say so.

_Pampa Notes 1.2.0 · 2026-01-02_
