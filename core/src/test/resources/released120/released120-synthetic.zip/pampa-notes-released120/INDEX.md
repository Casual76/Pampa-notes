# Indice: Compatibilità 1.2.0

2 note, 3 registrazioni, 0 min, 7 parole.

Ogni nota ha un file di appunti e un file per ogni lezione registrata; le lezioni lunghe sono divise in parti. Scegli per titolo e per data, e apri solo i file che servono alla domanda.

## Laboratorio / Fisica

### Energia e unità

January 2, 2026 · 3 registrazioni · 0 min

> Appunti sintetici Energia: E = mc². Un caffè e un'unità: µs.

- Appunti: [laboratorio--fisica--energia-e-unita.md](notes/laboratorio--fisica--energia-e-unita.md) · 12 parole
- January 2, 2026 · Ripulita selezionata · 0 min · 3 parole: [laboratorio--fisica--energia-e-unita--2026-01-02.md](notes/laboratorio--fisica--energia-e-unita--2026-01-02.md)
- January 2, 2026 · Grezza selezionata · 0 min · 4 parole: [laboratorio--fisica--energia-e-unita--2026-01-02-2.md](notes/laboratorio--fisica--energia-e-unita--2026-01-02-2.md)

## Laboratorio

### Solo testo

> Testo senza registrazioni.

- Appunti: [laboratorio--solo-testo.md](notes/laboratorio--solo-testo.md) · 3 parole

